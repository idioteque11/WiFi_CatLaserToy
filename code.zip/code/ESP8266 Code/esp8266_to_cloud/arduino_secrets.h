#define SECRET_SSID "xxxxxxx" //my WiFi network ID (hidden for privacy purposes, but of courses changed to the correct ID when uploading to my ESP8266)
#define SECRET_PASS "xxxxxxx" //my WiFi network password (hidden for privacy purposes, but of courses changed to the correct ID when uploading to my ESP8266)
#define SECRET_DEVICE_KEY "JPEX8ZTEVBDKJ8PZ3WKG" //unique ESP8266 device key assigned by Arduino IoT Cloud, i.e. the unique address of my ESP8266 
